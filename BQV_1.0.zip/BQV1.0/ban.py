import os
import time
from colorama import init, Fore, Style

# Ініціалізація colorama
init(autoreset=True)

# Шлях до файлу для перевірки маркера
turbo_boot_path = '/storage/emulated/0/Android/BQV1.0/TurboBoot.txt'

def clear_terminal():
    """Очищує термінал."""
    os.system('clear' if os.name == 'posix' else 'cls')

def is_banned():
    """Перевіряє, чи пристрій заблоковано."""
    try:
        with open(turbo_boot_path, 'r') as f:
            content = f.read().strip()
        return content == "Ban"
    except FileNotFoundError:
        return False

def trigger_ban_message():
    """Очищає екран та показує попередження у нескінченному циклі."""
    while True:
        clear_terminal()
        print(Fore.RED + Style.BRIGHT + "WARNING! The device was stitched without TurboBoot mode!")
        print(Fore.RED + Style.BRIGHT + "You got the eternal blocking of the device!")
        print(Fore.RED + Style.BRIGHT + "If you want to unlock, write to us in the telegram!")
        time.sleep(3)  # Пауза перед оновленням екрану

if __name__ == "__main__":
    if is_banned():
        trigger_ban_message()