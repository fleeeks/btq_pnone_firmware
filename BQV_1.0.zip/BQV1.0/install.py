import os
import time
import sys
from termcolor import colored

def clear_terminal():
    os.system('clear' if os.name == 'posix' else 'cls')

def display_welcome_message():
    clear_terminal()
    print(colored("Вас приветствует мастер установки BQV 1.0", 'yellow', attrs=['bold']))
    print(colored("Устанавливаю BQV 1.0...\n", 'yellow', attrs=['bold']))
    time.sleep(2)  # Задержка перед началом установки

def install_requirements():
    required_packages = [
        'colorama',    # Для цветного вывода
        'pyfiglet',    # Для ASCII-арта
        'Pillow',      # Для работы с изображениями
        'yt-dlp',      # Для загрузки видео с YouTube
        'numpy',       # Для работы с массивами (возможно, понадобится)
        'opencv-python',  # Для обработки изображений и видео
        'tzdata',      # Для работы с временными зонами
        'termcolor'    # Для цветного текста
    ]

    for package in required_packages:
        print(colored(f"Устанавливаю {package}...", 'yellow'))
        os.system(f'pip install {package}')

    print(colored("Установка завершена! Все необходимые библиотеки установлены.", 'green'))

def add_startup_script():
    startup_command = "python /path/to/your/main.py\n"  # Вкажіть правильний шлях до main.py
    bashrc_path = os.path.expanduser("~/.bashrc")  # Використовуйте ~/.bash_profile, якщо потрібно

    with open(bashrc_path, "a") as bashrc:
        bashrc.write(startup_command)

    print(colored("Команда для запуска main.py добавлена в ~/.bashrc.", 'green'))

def main():
    display_welcome_message()
    install_requirements()
    add_startup_script()
    
    # Запуск main.py после завершения установки
    print(colored("Запускаю основную программу...", 'yellow'))
    time.sleep(2)  # Задержка перед запуском
    os.system('python main.py')  # Запускаем основную программу

if __name__ == "__main__":
    main()