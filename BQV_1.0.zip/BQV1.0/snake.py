import os
import time
import random
import sys
from colorama import init, Fore, Style
import pyfiglet

# Ініціалізація colorama
init(autoreset=True)

def clear_terminal():
    os.system('clear' if os.name == 'posix' else 'cls')

def game_snake():
    clear_terminal()
    print(pyfiglet.figlet_format("SNAKE", font="slant"))
    print(Fore.GREEN + "Керування: W, S, D, A (вгору, вниз, вправо, вліво).")
    print(Fore.GREEN + "Вихід: X")
    
    # Змінні для гри
    width = 20
    height = 10
    snake = [(5, 5)]
    direction = 'RIGHT'
    food = (random.randint(1, height - 1), random.randint(1, width - 1))
    score = 0
    high_score = 0

    def draw():
        clear_terminal()
        print(pyfiglet.figlet_format("SNAKE", font="slant"))
        print(f"Score: {score} | High Score: {high_score}")
        # Малюємо межі
        for i in range(height + 2):
            if i == 0 or i == height + 1:
                print(Fore.RED + '|' + ' ' * width + '|')
            else:
                line = Fore.RED + '|'
                for j in range(width):
                    if (i-1, j) in snake:
                        line += Fore.GREEN + "■"
                    elif (i-1, j) == food:
                        line += Fore.RED + "★"
                    else:
                        line += " "
                line += Fore.RED + '|'
                print(line)
        print(Fore.GREEN + "Керування: W, S, D, A | Вихід: X")

    while True:
        draw()
        time.sleep(0.2)
        
        # Отримання вводу
        if os.name == 'nt':
            import msvcrt
            if msvcrt.kbhit():
                key = msvcrt.getch().decode()
        else:
            import tty, termios
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setraw(sys.stdin.fileno())
                key = sys.stdin.read(1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

        # Оновлення напрямку змійки
        if key == 'w' and direction != 'DOWN':
            direction = 'UP'
        elif key == 's' and direction != 'UP':
            direction = 'DOWN'
        elif key == 'd' and direction != 'LEFT':
            direction = 'RIGHT'
        elif key == 'a' and direction != 'RIGHT':
            direction = 'LEFT'
        elif key.lower() == 'x':
            clear_terminal()
            print(Fore.GREEN + "Повертаємось у меню...")
            return

        # Рух змійки
        head = snake[0]
        if direction == 'UP':
            new_head = (head[0] - 1, head[1])
        elif direction == 'DOWN':
            new_head = (head[0] + 1, head[1])
        elif direction == 'LEFT':
            new_head = (head[0], head[1] - 1)
        elif direction == 'RIGHT':
            new_head = (head[0], head[1] + 1)

        # Перевірка на зіткнення
        if (new_head in snake) or (new_head[0] < 1) or (new_head[0] >= height + 1) or (new_head[1] < 0) or (new_head[1] >= width):
            clear_terminal()
            print(Fore.RED + "Вы проиграли :( ")
            print(Fore.GREEN + f"SCORE: {score}")
            print(Fore.GREEN + "Нажмите Enter, чтобы вернуться в ГЛАВНОЕ меню...")
            input()

            # Запускаємо main.py після програшу
            os.system('python3 main.py')
            return

        snake.insert(0, new_head)

        # Перевірка, чи змійка з'їла їжу
        if new_head == food:
            score += 1
            high_score = max(high_score, score)
            food = (random.randint(1, height - 1), random.randint(1, width - 1))
        else:
            snake.pop()

if __name__ == "__main__":
    game_snake()