import os
import random
import sys
import time
import pyfiglet
from colorama import init, Fore

# Ініціалізація colorama
init(autoreset=True)

def clear_terminal():
    os.system('clear' if os.name == 'posix' else 'cls')

def print_title():
    title = pyfiglet.figlet_format("2048")
    print(title)

class Game2048:
    def __init__(self):
        self.grid = [[0] * 4 for _ in range(4)]
        self.score = 0
        self.add_random_tile()
        self.add_random_tile()

    def add_random_tile(self):
        empty_tiles = [(r, c) for r in range(4) for c in range(4) if self.grid[r][c] == 0]
        if empty_tiles:
            r, c = random.choice(empty_tiles)
            self.grid[r][c] = 2 if random.random() < 0.9 else 4

    def compress(self):
        new_grid = [[0] * 4 for _ in range(4)]
        for r in range(4):
            position = 0
            for c in range(4):
                if self.grid[r][c] != 0:
                    new_grid[r][position] = self.grid[r][c]
                    position += 1
        self.grid = new_grid

    def merge(self):
        for r in range(4):
            for c in range(3):
                if self.grid[r][c] == self.grid[r][c + 1] and self.grid[r][c] != 0:
                    self.grid[r][c] *= 2
                    self.score += self.grid[r][c]
                    self.grid[r][c + 1] = 0

    def reverse(self):
        for r in range(4):
            self.grid[r] = self.grid[r][::-1]

    def transpose(self):
        self.grid = [list(row) for row in zip(*self.grid)]

    def move_left(self):
        self.compress()
        self.merge()
        self.compress()

    def move_right(self):
        self.reverse()
        self.move_left()
        self.reverse()

    def move_up(self):
        self.transpose()
        self.move_left()
        self.transpose()

    def move_down(self):
        self.transpose()
        self.move_right()
        self.transpose()

    def has_won(self):
        return any(2048 in row for row in self.grid)

    def is_game_over(self):
        return not any(0 in row for row in self.grid) and not self.can_merge()

    def can_merge(self):
        for r in range(4):
            for c in range(3):
                if self.grid[r][c] == self.grid[r][c + 1] or self.grid[c][r] == self.grid[c + 1][r]:
                    return True
        return False

    def print_grid(self):
        clear_terminal()
        print_title()
        print(f"Счет: {self.score}")
        for row in self.grid:
            print("\t".join(str(num) if num != 0 else "." for num in row))
            print()

    def get_user_input(self):
        while True:
            command = input("Введите команду (w/a/s/d для движения, x для выхода): ").strip().lower()
            if command in ['w', 'a', 's', 'd', 'x']:
                return command
            print("Неверная команда. Попробуйте еще раз.")

    def play(self):
        while True:
            self.print_grid()
            command = self.get_user_input()

            if command == 'x':
                print(Fore.BLACK + "Выход из игры 2048...")
                time.sleep(5)  # Задержка 5 секунд перед перезапуском main.py
                os.system('python main.py')  # Перезапуск main.py
                break

            if command == 'w':
                self.move_up()
            elif command == 's':
                self.move_down()
            elif command == 'a':
                self.move_left()
            elif command == 'd':
                self.move_right()

            self.add_random_tile()

            if self.has_won():
                self.print_grid()
                print("Поздравляем! Вы достигли 2048!")
                break

            if self.is_game_over():
                self.print_grid()
                print("Игра окончена! Нет доступных ходов.")
                break

if __name__ == "__main__":
    game = Game2048()
    game.play()