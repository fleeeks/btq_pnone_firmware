import os
import time
from colorama import init, Fore, Style

# Ініціалізація colorama
init(autoreset=True)

def clear_terminal():
    os.system('clear' if os.name == 'posix' else 'cls')

def help_menu():
    while True:
        clear_terminal()  # Очищаємо термінал
        print(Fore.WHITE + Style.BRIGHT + "Commands:")
        
        # Розділ "Game"
        print(Fore.GREEN + Style.BRIGHT + "Game:")
        print(Fore.WHITE + "Game snake - игра \"змейка\"")
        print(Fore.WHITE + "Game 2048 - игра \"2048\"")
        print(Fore.WHITE + "Скоро будет еще;)")
        
        # Розділ "Special"
        print(Fore.GREEN + Style.BRIGHT + "\nSpecial:")
        print(Fore.WHITE + "Dev - меню разработчика")
        print(Fore.WHITE + "TurboBoot - режим \"TurboBoot\" позволяющий вам вносить свои файлы в систему изменять их и удалять, перепрошивать телефоны без блокировки девайса.")
        
        # Розділ "Контакти"
        print(Fore.CYAN + Style.BRIGHT + "\nTELEGRAM - @BTQ_DEV")
        print(Fore.CYAN + "СЛЕДИТЕ ЗА НОВОСТЯМИ;)")
        
        # Примітка з натисканням x
        print(Fore.RED + "Press x to back to menu")
        
        # Чекаємо введення команди
        exit_command = input(Fore.WHITE + Style.BRIGHT + "> ").strip().lower()
        
        if exit_command == "x":
            # Якщо натискаємо "x", переходимо до main.py
            os.system('python main.py')  # Повернення до main.py
            break  # Виходимо з циклу

if __name__ == "__main__":
    help_menu()