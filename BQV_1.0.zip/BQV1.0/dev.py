import os
import time
from termcolor import colored

def clear_terminal():
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    clear_terminal()
    # Вітання
    print(colored("Здраствуйте, вы находитесь в режиме разработчика. Для начала подтвердите что вы разработчик.", "yellow"))
    print(colored("Ведите пароль:", "red"))

    # Ввід пароля
    password = input(colored("> ", "red"))
    correct_password = "Dev0987654321"

    # Перевірка пароля
    if password == correct_password:
        clear_terminal()
        print(colored("DEVOPLER MODS", "red"))
        print(colored("Выберите действие:", "cyan"))
        print(colored("1.EXIT", "red"))
        action = input(colored("> ", "yellow"))

        if action == "1":
            print(colored("DEVOPLER MODE EXIT", "red"))
            time.sleep(5)
            os.system("python3 main.py")  # Запуск main.py
        else:
            print(colored("DEVOPLER MODE EXIT", "red"))
            time.sleep(5)
            os.system("python3 main.py")  # Запуск main.py
    else:
        print(colored("Пароль неверный!", "red"))
        time.sleep(5)
        os.system("python3 main.py")  # Запуск main.py у разі неправильного пароля

if __name__ == "__main__":
    main()