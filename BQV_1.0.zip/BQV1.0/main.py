import os
import sys
import time
import threading
from datetime import datetime
from colorama import init, Fore, Style

# Ініціалізація colorama
init(autoreset=True)

# Шлях до файлу для перевірки маркера
turbo_boot_path = '/storage/emulated/0/Android/BQV1.0/TurboBoot.txt'

def clear_terminal():
    os.system('clear' if os.name == 'posix' else 'cls')

def print_gradient_title():
    title = [
        Fore.WHITE + Style.BRIGHT + "██████╗░████████╗░██████╗░",
        Fore.BLACK + Style.BRIGHT + "██╔══██╗╚══██╔══╝██╔═══██╗",
        Fore.LIGHTBLACK_EX + Style.BRIGHT + "██████╦╝░░░██║░░░██║██╗██║",
        Fore.RED + Style.BRIGHT + "██╔══██╗░░░██║░░░╚██████╔╝",
        Fore.GREEN + Style.BRIGHT + "██████╦╝░░░██║░░░░╚═██╔═╝░",
        Fore.BLUE + Style.BRIGHT + "╚═════╝░░░░╚═╝░░░░░░╚═╝░░░",
        "\n",
        Fore.WHITE + Style.BRIGHT + "██████╗░██╗░░██╗░█████╗░███╗░░██╗███████╗",
        Fore.BLACK + Style.BRIGHT + "██╔══██╗██║░░██║██╔══██╗████╗░██║██╔════╝",
        Fore.LIGHTBLACK_EX + Style.BRIGHT + "██████╔╝███████║██║░░██║██╔██╗██║█████╗░░",
        Fore.RED + Style.BRIGHT + "██╔═══╝░██╔══██║██║░░██║██║╚████║██╔══╝░░",
        Fore.GREEN + Style.BRIGHT + "██║░░░░░██║░░██║╚█████╔╝██║░╚███║███████╗",
        Fore.BLUE + Style.BRIGHT + "╚═╝░░░░░╚═╝░░╚═╝░╚════╝░╚═╝░░╚══╝╚══════╝",
    ]
    
    for line in title:
        print(line)

def print_ascii_art():
    ascii_art = r"""
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

.
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⣀⣀⣀⣀
⠄⠄⠄⠄⠄⠄⢀⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶
⠄⠄⠄⠄⣠⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣤⡀
⠄⠄⣠⡾⠿⠛⠛⠉⠛⠛⠻⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣄
⢀⡶⠋⠄⣀⣤⣤⣶⣶⣶⣶⣶⣤⣍⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡄
⡼⣣⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡝⠻⣆
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣿⣿⡇⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠘⠂
⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⣿⣿⣠⣤⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀
⣿⣿⣿⣿⣿⣿⣿⣿⡿⢿⣿⠃⠄⠄⢸⣿⣿⢛⣿⣿⣿⣿⣿⣿⣿⡏⢿⣧
⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⢻⡿⣿⡘⣼⣿⣿⣿⣿⣏⢿⣷⠈⢿⡀
⢹⣿⣿⣿⣿⣿⣿⣿⠰⠓⠋⣿⣿⡿⠈⠄⣿⣿⣿⣿⣿⣿⣿⣿⡀⢻⡇⠘⣧⠄
⠄⢿⣿⣿⣿⣿⣿⣿⠄⠄⠄⠄⠄⠄⠄⠄⣿⣿⣿⣿⣿⣿⣿⣿⣇⠄⠻⡄⠈⠄
⠄⠘⣿⣿⣿⣿⣿⡇⢤⠄⠄⠄⠄⠄⠄⢀⡿⢹⣿⣿⣿⣿⣿⣿⣿⣆
⠄⠄⠸⣿⣿⣿⠛⢦⡀⠚⠍⠁⠄⠄⣠⠞⠁⣸⣿⣿⣿⣿⣿⣿⣿⡿⣆
⠄⠄⠄⠙⣿⣿⠄⠄⠉⠙⠓⣦⣤⣼⣿⣦⣴⣿⣿⣿⣿⠋⠻⣿⣿⣿⡝⠧
⠄⠄⠄⠄⠄⠹⠄⠄⠄⠄⠄⢸⣿⣿⣿⡇⢻⢩⣿⣿⡿⠛⠛⠿⣿⣯⣿⣆
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣿⣿⣿⠁⠈⣼⣿⡿⠄⠄⠄⠄⠙⣿⣿⢿⣆
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣿⣿⡟⠄⢀⣿⡟⡇⠄⠄⠄⠄⠄⠸⣿⣿⢿⡄
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢀⣿⣿⡟⠄⠄⢸⣿⠃⣿⡀⠄⠄⠄⠄⠄⢹⣿⣟⣷
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣼⡿⢻⢁⢀⣠⣿⡿⠄⣿⢷⠄⠄⠄⠄⠄⠈⣿⣿⢹
⠄⠄⠄⠄⠄⠄⠄⠄⠄⣰⡿⠁⢸⡿⠋⠄⣿⠄⠄⢹⣌⢳⡀⠄⠄⠄⠄⢸⣿⠈
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠟⠁⠄⠄⠄⠄⠄⠹⠄⠄⠄⠙⣮⣷⡀⠄⠄⠄⠘⣿
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠈⠉⠁⠄⠄⠄⠄⠉
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"""
    print(Fore.RED + ascii_art)
    print(Fore.BLUE + Style.BRIGHT + "BY " + Style.BRIGHT + Fore.YELLOW + "FLEEKS")

def update_time():
    global current_date, current_time
    now = datetime.now()
    current_time = now.strftime("%H:%M")
    current_date = now.strftime("%Y-%m-%d")

def display_time_date():
    clear_terminal()
    print_gradient_title()
    print_ascii_art()
    
    print("\n\n\n" + Fore.LIGHTBLACK_EX + "PHONE SETTINGS:")
    print(Fore.GREEN + "BQV " + Fore.BLUE + "1.0")
    
    now = datetime.now()
    current_time = now.strftime("%H:%M")
    current_date = now.strftime("%Y-%m-%d")
    
    print(Fore.GREEN + Style.BRIGHT + f"{current_date} {current_time}")

    print("\n\n" + Fore.YELLOW + "> ", end="", flush=True)

def start_turbo_boot():
    clear_terminal()
    print(Fore.RED + "Note: You downloaded this file at your own peril and risk.")
    time.sleep(1)
    print(Fore.WHITE + Style.BRIGHT + "Start TurboBoot...")
    time.sleep(5)
    os.system('python TurboBoot.py')

def start_check():
    os.system('python check.py &')

def is_banned():
    """Перевіряє, чи пристрій заблоковано."""
    try:
        with open(turbo_boot_path, 'r') as f:
            content = f.read().strip()
        return content == "Ban"
    except FileNotFoundError:
        return False

# Перевірка на маркер "Ban" перед запуском основного коду
if is_banned():
    os.system('python ban.py' if os.name == 'posix' else 'python ban.py')
    sys.exit()

def main():
    start_check()
    while True:
        update_time()
        display_time_date()
        
        command = input().strip().lower()

        if command == "game snake":
            print(Fore.YELLOW + "Запускаю змейку...")
            time.sleep(5)
            os.system('python snake.py')
        elif command == "game 2048":
            print(Fore.YELLOW + "Запускаю 2048...")
            time.sleep(5)
            os.system('python 2048.py')
        elif command == "random image":
            print(Fore.YELLOW + "Запускаю случайное изображение...")
            time.sleep(5)
            os.system('python ri.py')
        elif command == "calculator":
            print(Fore.YELLOW + "Запускаю калькулятор...")
            time.sleep(5)
            os.system('python calculator.py')
        elif command == "dev":
            print(Fore.RED + "Start Developer Mode...")
            time.sleep(5)
            os.system('python dev.py')
        elif command == "restart":
            print(Fore.YELLOW + "Перезапуск...")
            time.sleep(5)
            os.execv(sys.executable, ['python'] + sys.argv)
        elif command == "exit":
            print(Fore.RED + "Выход из программы...")
            break
        elif command == "turboboot":
            start_turbo_boot()
        elif command == "help":
            print(Fore.YELLOW + "Запускаю справку")
            time.sleep(2)
            os.system('python help.py')
        else:
            print(Fore.YELLOW + "Неверная команда. Попробуйте снова.")
            time.sleep(5)

if __name__ == "__main__":
    main()