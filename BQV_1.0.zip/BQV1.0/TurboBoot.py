import os
import sys
import time
from colorama import init, Fore, Style
import pyfiglet  # Для створення великого тексту

# Ініціалізація colorama
init(autoreset=True)

# Шлях до файлу для маркера TurboBoot
turbo_boot_path = '/storage/emulated/0/Android/BQV1.0/TurboBoot.txt'

# Змінна для відслідковування виходу користувача
exit_flag = False

def clear_terminal():
    os.system('clear' if os.name == 'posix' else 'cls')

def turbo_boot_intro():
    global exit_flag
    clear_terminal()
    print(Fore.WHITE + Style.BRIGHT + "Hello! This TurboBoot. Here you can hand over your BTQ-PHONE! We are not responsible for you and your phone!")
    print(Fore.WHITE + "If you are trying to install the firmware, submit an application through the developer menu and the hill will be blocked by the entrance to the system!")
    print(Fore.WHITE + "If you have questions/problems, inform us in telegram!")
    print(Fore.WHITE + "Write yes if you agree reflash your BTQ-PHONE!")
    print("\n")
    
    # Запит на підтвердження
    answer = input(Fore.WHITE + Style.BRIGHT + "> ").strip().lower()
    
    if answer == "yes":
        print(Fore.GREEN + "Ok, redirect you to TurboBoot")
        print(Fore.GREEN + "Good Luck!")
        time.sleep(2)  # Затримка 2 секунди
        activate_turbo_boot()  # Активуємо TurboBoot
        time.sleep(2)  # Час на підтвердження
        turbo_boot_proceed()
    else:
        print(Fore.RED + "Aborted")
        time.sleep(2)
        os.system('python main.py')  # Перехід до main.py, якщо відмова

def activate_turbo_boot():
    # Записуємо маркер активації режиму в файл
    with open(turbo_boot_path, 'w') as f:
        f.write("TurboBoot Active\n")  # Текст, що режим активований

def reset_turbo_boot():
    # Скидаємо маркер активації в файл
    with open(turbo_boot_path, 'w') as f:
        f.write("TurboBoot Reset\n")  # Маркер, що режим скинутий

def turbo_boot_proceed():
    global exit_flag
    clear_terminal()
    
    # Використовуємо pyfiglet для великого тексту
    ascii_art = pyfiglet.figlet_format("TurboBoot")
    
    # Центруємо великий текст
    print(Fore.CYAN + Style.BRIGHT + ascii_art)
    
    # Примітки та побажання удачі внизу
    print(Fore.GREEN + "               Good luck;)")
    print("\n")
    print(Fore.WHITE + "Note: Exit to press x!")
    
    # Чекаємо на введення x для виходу
    exit_command = input(Fore.WHITE + Style.BRIGHT + "> ").strip().lower()
    
    if exit_command == "x":
        exit_flag = True  # Встановлюємо flag виходу
        time.sleep(2)  # Час для сприйняття повідомлення
        show_remaining_time()  # Показуємо ще 5 хвилин
        reset_turbo_boot()  # Скидаємо маркер після завершення сесії
        os.system('python main.py')  # Перехід до main.py при натисканні x

def show_remaining_time():
    global exit_flag
    # Виводимо повідомлення про TurboBoot ще протягом 5 хвилин
    for remaining in range(300, 0, -1):  # 300 секунд = 5 хвилин
        clear_terminal()
        minutes = remaining // 60
        seconds = remaining % 60
        
        # Якщо користувач вийшов з TurboBoot, припиняємо таймер
        if exit_flag:
            print(Fore.GREEN + "You have exited TurboBoot mode.")
            break
        
        print(Fore.RED + Style.BRIGHT + "TurboBoot was active!")
        print(Fore.RED + "This device was heated without TURBOBOOT!")
        print(Fore.RED + f"Remaining time: {minutes} minutes and {seconds} seconds")
        time.sleep(1)  # Затримка 1 секунда
        
    if not exit_flag:
        print(Fore.RED + "TurboBoot mode ended.")
        time.sleep(1)  # Затримка перед повним завершенням

if __name__ == "__main__":
    turbo_boot_intro()