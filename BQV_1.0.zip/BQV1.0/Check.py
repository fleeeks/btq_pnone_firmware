import os
import time
import hashlib
import subprocess

# Шлях до директорії та файлів для моніторингу
directory_path = '/storage/emulated/0/Android/BQV1.0/'
turbo_boot_path = os.path.join(directory_path, 'TurboBoot.txt')

# Функція для перевірки змін у файлах
def check_for_changes():
    # Створюємо словник для збереження хешів файлів
    files_hashes = {}

    # Проходимо через всі файли в директорії та створюємо хеші
    for root, dirs, files in os.walk(directory_path):
        for file in files:
            file_path = os.path.join(root, file)
            if file != 'TurboBoot.txt':  # Не перевіряємо сам файл TurboBoot.txt
                with open(file_path, 'rb') as f:
                    file_data = f.read()
                    file_hash = hashlib.md5(file_data).hexdigest()
                    files_hashes[file_path] = file_hash

    return files_hashes

# Функція для оновлення маркера в TurboBoot.txt
def mark_as_ban():
    with open(turbo_boot_path, 'w') as f:
        f.write("Ban")  # Встановлюємо маркер про блокування

# Функція для перевірки маркера в TurboBoot.txt
def check_turbo_boot_marker():
    try:
        with open(turbo_boot_path, 'r') as f:
            content = f.read().strip()
        return content
    except FileNotFoundError:
        return None

# Функція для моніторингу змін
def monitor_changes():
    initial_hashes = check_for_changes()  # Отримуємо початкові хеші файлів

    while True:
        time.sleep(10)  # Перевіряємо кожні 10 секунд

        # Отримуємо поточні хеші файлів
        current_hashes = check_for_changes()

        # Перевіряємо, чи є зміни
        for file_path, file_hash in current_hashes.items():
            if file_path not in initial_hashes or initial_hashes[file_path] != file_hash:
                print(f"Change detected in file: {file_path}")
                
                # Перевіряємо вміст TurboBoot.txt
                turbo_boot_marker = check_turbo_boot_marker()

                if turbo_boot_marker != "TurboBoot Active":  # Якщо режим не активований
                    print("TurboBoot mode not active, setting Ban marker.")
                    mark_as_ban()  # Ставимо маркер "Ban" в TurboBoot.txt

                    # Перевіряємо, чи є вже маркер "Ban"
                    if check_turbo_boot_marker() == "Ban":  # Якщо в TurboBoot.txt є маркер "Ban"
                        print("Ban marker detected, opening ban.py.")
                        subprocess.run(["python", "ban.py"])  # Запускаємо ban.py

                else:
                    print("TurboBoot mode is active, no action required.")
                break  # При виявленні змін припиняємо перевірку (можна додати додаткову логіку для багатьох змін)

        initial_hashes = current_hashes  # Оновлюємо хеші для наступної перевірки

if __name__ == "__main__":
    monitor_changes()  # Запускаємо моніторинг змін